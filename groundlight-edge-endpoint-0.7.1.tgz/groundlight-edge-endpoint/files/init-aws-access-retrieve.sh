#!/bin/bash

# Part one of getting AWS credentials set up.
# This script runs in a aws-cli container and retrieves the credentials from Janzu.
# Then it uses the credentials to get a login token for ECR.
#
# It saves three files to the shared volume for use by part two:
# 1. /shared/credentials: The AWS credentials file that can be mounted into pods at ~/.aws/credentials
# 2. /shared/token.txt: The ECR login token that can be used to pull images from ECR. This will
#    be used to create a registry secret in k8s.
# 3. /shared/done: A marker file to indicate that the script has completed successfully.

# Note: This script is also used to validate the GROUNDLIGHT_API_TOKEN and GROUNDLIGHT_ENDPOINT
# settings. If you run it with the first argument being "validate", it will only run through the 
# check of the curl results and exit with 0 if they are valid or 1 if they are not. In the latter 
# case, it will also log the results.

if [ "$1" == "validate" ]; then
  echo "Validating GROUNDLIGHT_API_TOKEN and GROUNDLIGHT_ENDPOINT..."
  if [ -z "$GROUNDLIGHT_API_TOKEN" ]; then
    echo "GROUNDLIGHT_API_TOKEN is not set. Exiting."
    exit 1
  fi

  if [ -z "$GROUNDLIGHT_ENDPOINT" ]; then
    echo "GROUNDLIGHT_ENDPOINT is not set. Exiting."
    exit 1
  fi
  validate="yes"
fi

# Prefer a working token from the SDK device cache when present. The Python
# containers (edge-endpoint, status-monitor, escalation-queue-reader,
# inference-model-updater) own rotation and write
# $GROUNDLIGHT_TOKEN_DIR/<seed-snippet>.json; this job only reads it.
# Snippet length matches python-sdk TokenManager.TOKEN_SNIPPET_LENGTH (20).
resolve_groundlight_api_token() {
  local seed="$GROUNDLIGHT_API_TOKEN"
  if [ -z "$seed" ]; then
    echo "GROUNDLIGHT_API_TOKEN is not set. Exiting." >&2
    exit 1
  fi

  if [ -z "${GROUNDLIGHT_TOKEN_DIR:-}" ]; then
    echo "GROUNDLIGHT_TOKEN_DIR unset; using seed GROUNDLIGHT_API_TOKEN" >&2
    echo "$seed"
    return
  fi

  local snippet="${seed:0:20}"
  local cache_file="${GROUNDLIGHT_TOKEN_DIR}/${snippet}.json"
  if [ ! -f "$cache_file" ]; then
    echo "No device token cache at ${cache_file}; using seed GROUNDLIGHT_API_TOKEN" >&2
    echo "$seed"
    return
  fi

  local cached
  cached=$(jq -r '.current.raw_key // empty' "$cache_file" 2>/dev/null || true)
  if [ -n "$cached" ]; then
    echo "Using rotated device API token from cache: ${cache_file}" >&2
    echo "$cached"
    return
  fi

  echo "Token cache present but missing current.raw_key; falling back to seed: ${cache_file}" >&2
  echo "$seed"
}

GROUNDLIGHT_API_TOKEN="$(resolve_groundlight_api_token)"
export GROUNDLIGHT_API_TOKEN

# This function replicates the Groundlight SDK's logic to clean up user-supplied endpoint URLs 
sanitize_endpoint_url() {
    local endpoint="${1:-$GROUNDLIGHT_ENDPOINT}"

    # If empty, set default
    if [[ -z "$endpoint" ]]; then
        endpoint="https://api.groundlight.ai/"
    fi

    # Parse URL scheme and the rest
    if [[ "$endpoint" =~ ^(https?)://([^/]+)(/.*)?$ ]]; then
        scheme="${BASH_REMATCH[1]}"
        netloc="${BASH_REMATCH[2]}"
        path="${BASH_REMATCH[3]}"
    else
        echo "Invalid API endpoint: $endpoint. Must be a valid URL with http or https scheme." >&2
        exit 1
    fi

    # Ensure path is properly initialized
    if [[ -z "$path" ]]; then
        path="/"
    fi

    # Ensure path ends with "/"
    if [[ "${path: -1}" != "/" ]]; then
        path="$path/"
    fi

    # Set default path if just "/"
    if [[ "$path" == "/" ]]; then
        path="/device-api/"
    fi

    # Allow only specific paths
    case "$path" in
        "/device-api/"|"/v1/"|"/v2/"|"/v3/")
            ;;
        *)
            echo "Warning: Configured endpoint $endpoint does not look right - path '$path' seems wrong." >&2
            ;;
    esac

    # Remove trailing slash for output
    sanitized_endpoint="${scheme}://${netloc}${path%/}"
    echo "$sanitized_endpoint"
}

sanitized_url=$(sanitize_endpoint_url "${GROUNDLIGHT_ENDPOINT}")
echo "Sanitized URL: $sanitized_url"

echo "Fetching temporary AWS credentials from the Groundlight cloud service..."
CREDENTIALS_FILE="/tmp/credentials.json"
CURL_ERROR_FILE="/tmp/credentials.curl.err"
HTTP_STATUS=""
CURL_EXIT_CODE=0

for attempt in 1 2 3 4 5; do
  rm -f "$CREDENTIALS_FILE" "$CURL_ERROR_FILE"
  HTTP_STATUS=$(curl -sS -L -o "$CREDENTIALS_FILE" -w "%{http_code}" --fail-with-body \
    --header "x-api-token: ${GROUNDLIGHT_API_TOKEN}" "${sanitized_url}/reader-credentials/v2" \
    2>"$CURL_ERROR_FILE")
  CURL_EXIT_CODE=$?

  if [ $CURL_EXIT_CODE -eq 0 ]; then
    break
  fi

  if [ "$HTTP_STATUS" != "000" ] || [ "$attempt" -eq 5 ]; then
    break
  fi

  echo "Credential fetch attempt $attempt failed before receiving an HTTP response. Retrying..."
  if [ -s "$CURL_ERROR_FILE" ]; then
    echo -n "curl error: "
    cat "$CURL_ERROR_FILE"; echo
  fi
  sleep 5
done

if [ $CURL_EXIT_CODE -ne 0 ]; then
  echo "Failed to fetch credentials from the Groundlight cloud service"
  echo "curl exit code: $CURL_EXIT_CODE"
  if [ -n "$HTTP_STATUS" ]; then
    echo "HTTP Status: $HTTP_STATUS"
  fi
  if [ -s "$CURL_ERROR_FILE" ]; then
    echo -n "curl error: "
    cat "$CURL_ERROR_FILE"; echo
  fi
  echo -n "Response: "
  if [ -f "$CREDENTIALS_FILE" ]; then
    cat "$CREDENTIALS_FILE"; echo
  else
    echo "(no response body)"
  fi
  exit 1
fi

if [ "$validate" == "yes" ]; then

  echo "API token validation successful. Exiting."
  exit 0
fi

export AWS_ACCESS_KEY_ID=$(sed 's/^.*"access_key_id":"\([^"]*\)".*$/\1/' /tmp/credentials.json)
export AWS_SECRET_ACCESS_KEY=$(sed 's/^.*"secret_access_key":"\([^"]*\)".*$/\1/' /tmp/credentials.json)
export AWS_SESSION_TOKEN=$(sed 's/^.*"session_token":"\([^"]*\)".*$/\1/' /tmp/credentials.json)

cat <<EOF > /shared/credentials
[default]
aws_access_key_id = ${AWS_ACCESS_KEY_ID}
aws_secret_access_key = ${AWS_SECRET_ACCESS_KEY}
aws_session_token = ${AWS_SESSION_TOKEN}
EOF

echo "Credentials fetched and saved to /shared/credentials"
cat /shared/credentials; echo

echo "Fetching AWS ECR login token..."
if ! TOKEN=$(aws ecr get-login-password --region {{ include "groundlight-edge-endpoint.ecrRegion" . }}); then
  echo "Failed to get an ECR login token for region {{ include "groundlight-edge-endpoint.ecrRegion" . }}" >&2
  exit 1
fi
if [ -z "$TOKEN" ]; then
  echo "ECR login token was empty" >&2
  exit 1
fi
printf '%s' "$TOKEN" > /shared/token.txt

echo "Token fetched and saved to /shared/token.txt"

touch /shared/done
